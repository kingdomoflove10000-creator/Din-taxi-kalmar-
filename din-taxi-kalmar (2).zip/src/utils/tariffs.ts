export type Tariff = {
  id: "weekday" | "other" | "large";
  label: string;
  title: string;
  hours: string;
  base: number;
  perKilometer: number;
  perHour: number;
  comparison: number;
};

export const tariffs: Tariff[] = [
  {
    id: "weekday",
    label: "Taxa 1",
    title: "Vardagar",
    hours: "08:00-15:00",
    base: 65,
    perKilometer: 26,
    perHour: 500,
    comparison: 450,
  },
  {
    id: "other",
    label: "Taxa 2",
    title: "Övriga tider",
    hours: "15:00-08:00",
    base: 65,
    perKilometer: 27,
    perHour: 600,
    comparison: 485,
  },
  {
    id: "large",
    label: "Taxa 3",
    title: "Storbil",
    hours: "00:00-24:00",
    base: 80,
    perKilometer: 30,
    perHour: 1000,
    comparison: 630,
  },
];

export const airportFee = 25;

const stockholmClock = new Intl.DateTimeFormat("sv-SE", {
  timeZone: "Europe/Stockholm",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
});

export function stockholmLocalDateTime(date: Date): string {
  const parts = Object.fromEntries(
    stockholmClock.formatToParts(date).map(({ type, value }) => [type, value]),
  );
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
}

function parseLocalDateTime(value: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(value);
  if (!match) return null;
  const [year, month, day, hour, minute] = match.slice(1).map(Number);
  const date = new Date(Date.UTC(year, month - 1, day, hour, minute));
  if (
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() !== month - 1 ||
    date.getUTCDate() !== day ||
    date.getUTCHours() !== hour ||
    date.getUTCMinutes() !== minute
  )
    return null;
  return date;
}

export function formatLocalDateTime(value: string): string {
  const date = parseLocalDateTime(value);
  if (!date) return value;
  return new Intl.DateTimeFormat("sv-SE", {
    dateStyle: "long",
    timeStyle: "short",
    timeZone: "UTC",
  }).format(date);
}

function easterSunday(year: number): number {
  // Gregorian Easter date for Sweden's movable public holidays.
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return Date.UTC(year, month - 1, day);
}

function isPublicHoliday(date: Date): boolean {
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  const day = date.getUTCDate();
  const fixedHolidays = ["1-1", "1-6", "5-1", "6-6", "12-25", "12-26"];
  if (fixedHolidays.includes(`${month}-${day}`)) return true;
  const dateAtMidnight = Date.UTC(year, month - 1, day);
  const daysFromEaster = (dateAtMidnight - easterSunday(year)) / 86400000;
  return [-2, 1, 39].includes(daysFromEaster);
}

export function standardTariffForTime(localDateTime: string): Tariff | null {
  const date = parseLocalDateTime(localDateTime);
  if (!date) return null;
  const minutes = date.getUTCHours() * 60 + date.getUTCMinutes();
  if (minutes < 8 * 60 || minutes >= 15 * 60) return tariffs[1];

  // The notice does not specify weekend daytime rates; never guess them.
  const weekday = date.getUTCDay();
  if (weekday === 0 || weekday === 6 || isPublicHoliday(date)) return null;
  return tariffs[0];
}
