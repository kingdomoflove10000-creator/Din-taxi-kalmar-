import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  AnimatePresence,
  motion,
  MotionConfig,
  useReducedMotion,
} from "motion/react";
import {
  ArrowDown,
  ArrowDownUp,
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronDown,
  Clock3,
  Copy,
  MapPin,
  Menu,
  Minus,
  Navigation,
  Phone,
  Plus,
  ShieldCheck,
  Star,
  Users,
  X,
} from "lucide-react";
import {
  airportFee,
  formatLocalDateTime,
  standardTariffForTime,
  stockholmLocalDateTime,
  tariffs,
} from "./utils/tariffs";

const PHONE = "0480-47 47 47";
const PHONE_LINK = "tel:+46480474747";
const places = [
  "Kalmar Centralstation",
  "Kalmar Öland Airport",
  "Kalmar Slott",
  "Stortorget, Kalmar",
  "Länssjukhuset i Kalmar",
  "Linnéuniversitetet, Kalmar",
  "Färjestaden, Öland",
  "Nybro station",
  "Borgholm, Öland",
  "Lindsdal, Kalmar",
];

const services = [
  {
    number: "01",
    title: "Din vardag. Din taxi.",
    description:
      "Till jobbet, tåget eller en kväll på stan. Vi kan Kalmar och tar dig hela vägen hem.",
    image: "/images/kalmar-castle.jpg",
    fallbackImage:
      "https://images.pexels.com/photos/33396540/pexels-photo-33396540.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200",
    alt: "Kalmar Slott speglar sig i det stilla vattnet",
    destination: "",
    pickup: "",
    label: "Boka en resa i Kalmar",
  },
  {
    number: "02",
    title: "En flygande start.",
    description:
      "Börja resan i lugn och ro. Vi kör dig till och från Kalmar Öland Airport.",
    image: "/images/flight.jpg",
    fallbackImage:
      "https://images.pexels.com/photos/11618710/pexels-photo-11618710.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200",
    alt: "Flygplansvinge över molnen i kvällsljus",
    destination: "Kalmar Öland Airport",
    pickup: "",
    label: "Boka flygplatstaxi",
  },
  {
    number: "03",
    title: "På väg i jobbet.",
    description:
      "Från första mötet till sista stoppet. Personliga resor för dig, kollegorna och kunderna.",
    image: "/images/interior.jpg",
    fallbackImage:
      "https://images.pexels.com/photos/14667496/pexels-photo-14667496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200",
    alt: "Rymligt och bekvämt baksäte i en premiumbil",
    destination: "",
    pickup: "",
    label: "Planera en företagsresa",
  },
];

const questions = [
  {
    question: "Hur bokar jag en taxi?",
    answer:
      "Fyll i var du vill bli hämtad och vart du ska i bokningsfältet. Du får en tydlig sammanfattning av din resa och ringer sedan oss på 0480-47 47 47 för att bekräfta tid, pris och tillgänglighet. Du kan också ringa oss direkt, dygnet runt. Ingen app eller registrering behövs.",
  },
  {
    question: "Kan jag boka en resa i förväg?",
    answer:
      "Absolut. Välj ”Välj datum & tid” i bokningsfältet och ange när du vill resa. Ring sedan oss för att bekräfta bokningen. Förbokning är ett bra val för tidiga flyg, tågresor och viktiga möten.",
  },
  {
    question: "Kör ni till Kalmar Öland Airport?",
    answer:
      "Ja, vi kör både till och från Kalmar Öland Airport. Berätta gärna ditt flygnummer och hur mycket bagage du har när du ringer, så hjälper vi dig att planera upphämtningen.",
  },
  {
    question: "Vad kostar min resa?",
    answer:
      "Priset beror på grundavgift, sträcka, restid, tidpunkt och vilken bil du behöver. Jämförpriset gäller en exempelresa på 10 km som tar 15 minuter, inte ett fast pris för din resa. Flygplatsavgift på 25 kr tillkommer vid flygplatsresa, och andra avgifter kan tillkomma. Ring 0480-47 47 47 så hjälper vi dig med rätt taxa.",
  },
  {
    question: "Kör ni även på Öland och utanför Kalmar?",
    answer:
      "Ja, vi kör i Kalmar med omnejd, bland annat Färjestaden, Borgholm, Nybro, Lindsdal och Mönsterås. Ska du längre? Ring oss så hittar vi ett upplägg för din resa.",
  },
  {
    question: "Kan jag ta med barnstol eller extra bagage?",
    answer:
      "Berätta om barnstol, större bagage, djur eller andra önskemål när du bokar på telefon. Då kan vi bekräfta att rätt bil och utrustning finns tillgänglig för din resa.",
  },
];

function Brand({ light = false }: { light?: boolean }) {
  return (
    <a
      className={`brand ${light ? "brand-light" : ""}`}
      href="#hem"
      aria-label="Din Taxi Kalmar, till startsidan"
    >
      <svg
        className="brand-symbol"
        viewBox="0 0 40 42"
        fill="none"
        aria-hidden="true"
      >
        <path d="M11 4h11L11 24H0L11 4Z" fill="currentColor" />
        <path d="M26 4h11L15 42H4L26 4Z" fill="currentColor" />
        <path d="M29 23h11L29 42H18L29 23Z" fill="currentColor" />
      </svg>
      <span className="brand-type">
        din taxi<span>KALMAR</span>
      </span>
    </a>
  );
}

function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const reduceMotion = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduceMotion ? false : { opacity: 0, y: 26 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

function Dialog({
  children,
  onClose,
  titleId,
}: {
  children: ReactNode;
  onClose: () => void;
  titleId: string;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const reduceMotion = useReducedMotion();
  useEffect(() => {
    const dialog = ref.current;
    const previousOverflow = document.body.style.overflow;
    const previouslyFocused = document.activeElement as HTMLElement | null;
    dialog?.showModal();
    document.body.style.overflow = "hidden";
    return () => {
      dialog?.close();
      document.body.style.overflow = previousOverflow;
      previouslyFocused?.focus({ preventScroll: true });
    };
  }, []);

  return (
    <dialog
      ref={ref}
      className="dialog"
      aria-labelledby={titleId}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      onKeyDown={(event) => {
        if (event.key !== "Tab") return;
        const controls = Array.from(
          event.currentTarget.querySelectorAll<HTMLElement>(
            'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex="0"]',
          ),
        ).filter((element) => element.getClientRects().length > 0);
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }}
    >
      <motion.div
        className="dialog-inner"
        initial={reduceMotion ? false : { opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <button
          className="icon-button dialog-close"
          onClick={onClose}
          aria-label="Stäng dialog"
        >
          <X size={21} />
        </button>
        {children}
      </motion.div>
    </dialog>
  );
}

function App() {
  const reducedMotion = useReducedMotion();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [pickup, setPickup] = useState("");
  const [destination, setDestination] = useState("");
  const [timing, setTiming] = useState("now");
  const [scheduledAt, setScheduledAt] = useState("");
  const [bookingAt, setBookingAt] = useState("");
  const [passengers, setPassengers] = useState(1);
  const [formError, setFormError] = useState("");
  const [bookingOpen, setBookingOpen] = useState(false);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "error">(
    "idle",
  );
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [legal, setLegal] = useState<"privacy" | "accessibility" | null>(null);
  const pickupRef = useRef<HTMLInputElement>(null);
  const focusTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => {
    if (!menuOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [menuOpen]);
  useEffect(() => {
    if (!bookingOpen || timing !== "now") return;
    const timer = setInterval(
      () => setBookingAt(stockholmLocalDateTime(new Date())),
      1000,
    );
    return () => clearInterval(timer);
  }, [bookingOpen, timing]);
  useEffect(
    () => () => {
      if (focusTimer.current) clearTimeout(focusTimer.current);
    },
    [],
  );

  function goToBooking(preset?: { pickup?: string; destination?: string }) {
    if (preset) {
      setPickup(preset.pickup ?? "");
      setDestination(preset.destination ?? "");
    }
    setFormError("");
    setMenuOpen(false);
    document.getElementById("boka")?.scrollIntoView({
      behavior: reducedMotion ? "instant" : "smooth",
      block: "center",
    });
    if (focusTimer.current) clearTimeout(focusTimer.current);
    focusTimer.current = setTimeout(
      () => pickupRef.current?.focus({ preventScroll: true }),
      reducedMotion ? 0 : 500,
    );
  }

  function handleBooking(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!pickup.trim() || !destination.trim()) {
      setFormError("Fyll i både upphämtningsplats och destination.");
      return;
    }
    if (
      pickup.trim().toLocaleLowerCase("sv") ===
      destination.trim().toLocaleLowerCase("sv")
    ) {
      setFormError("Upphämtning och destination behöver vara olika platser.");
      return;
    }
    if (
      timing === "scheduled" &&
      (!scheduledAt || scheduledAt <= stockholmLocalDateTime(new Date()))
    ) {
      setFormError("Välj ett datum och en tid som ligger framåt i tiden.");
      return;
    }
    setFormError("");
    setCopyState("idle");
    setBookingAt(
      timing === "now" ? stockholmLocalDateTime(new Date()) : scheduledAt,
    );
    setBookingOpen(true);
  }

  const journeyTime =
    timing === "now"
      ? "Så snart som möjligt"
      : scheduledAt
        ? formatLocalDateTime(scheduledAt)
        : "";
  const journeyTariff =
    passengers > 4 ? tariffs[2] : standardTariffForTime(bookingAt);

  async function copyJourney() {
    try {
      await navigator.clipboard.writeText(
        `Taxiresa med Din Taxi Kalmar\nFrån: ${pickup.trim()}\nTill: ${destination.trim()}\nNär: ${journeyTime}\nResenärer: ${passengers}\nBoka på ${PHONE}. Resan bekräftas på telefon.`,
      );
      setCopyState("copied");
    } catch {
      setCopyState("error");
    }
  }

  return (
    <MotionConfig reducedMotion="user">
      <a href="#main" className="skip-link">
        Hoppa till innehållet
      </a>
      <header className={`site-header ${scrolled ? "is-scrolled" : ""}`}>
        <div className="container nav-inner">
          <Brand />
          <nav className="desktop-nav" aria-label="Huvudnavigation">
            <a href="#tjanster">Våra tjänster</a>
            <a href="#sa-funkar-det">Så funkar det</a>
            <a href="#priser">Våra priser</a>
            <a href="#fragor">Vanliga frågor</a>
          </nav>
          <div className="nav-actions">
            <a className="nav-phone" href={PHONE_LINK}>
              <Phone size={16} />
              <span>{PHONE}</span>
            </a>
            <a href="#boka" className="button button-lime nav-book">
              Boka taxi <ArrowUpRight size={18} />
            </a>
            <button
              className="icon-button menu-toggle"
              aria-label={menuOpen ? "Stäng meny" : "Öppna meny"}
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        <AnimatePresence>
          {menuOpen && (
            <motion.nav
              id="mobile-menu"
              className="mobile-menu"
              aria-label="Mobilnavigation"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25 }}
            >
              {[
                ["Våra tjänster", "#tjanster"],
                ["Så funkar det", "#sa-funkar-det"],
                ["Våra priser", "#priser"],
                ["Vanliga frågor", "#fragor"],
              ].map(([label, href]) => (
                <a key={href} href={href} onClick={() => setMenuOpen(false)}>
                  {label}
                  <ArrowUpRight size={21} />
                </a>
              ))}
              <a className="mobile-call" href={PHONE_LINK}>
                <Phone size={18} />
                {PHONE}
                <span>Dygnet runt</span>
              </a>
            </motion.nav>
          )}
        </AnimatePresence>
      </header>

      <main id="main">
        <section className="hero" id="hem" aria-labelledby="hero-title">
          <motion.img
            className="hero-image"
            src="/images/kalmar-taxi-hero.jpg"
            fetchPriority="high"
            alt="En svart taxibil vid vattnet med Kalmar Slott i bakgrunden"
            initial={reducedMotion ? false : { scale: 1.065 }}
            animate={{ scale: 1 }}
            transition={{ duration: 2.2, ease: [0.16, 1, 0.3, 1] }}
          />
          <div className="hero-shade" />
          <div className="container hero-content">
            <motion.div
              className="eyebrow hero-eyebrow"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <span className="live-dot" /> DIN LOKALA TAXI. DYGNET RUNT.
            </motion.div>
            <motion.h1
              id="hero-title"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.8,
                delay: 0.18,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              Din taxi.
              <br />
              Ditt <span>Kalmar.</span>
            </motion.h1>
            <motion.p
              className="hero-description"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
            >
              Från första morgonflyget till sista svängen hem.
              <br className="desktop-break" /> Vi finns här, när du vill komma
              fram.
            </motion.p>
            <motion.div
              className="hero-actions"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
            >
              <a href="#boka" className="button button-lime hero-book">
                Boka din resa <ArrowUpRight size={21} />
              </a>
              <a href={PHONE_LINK} className="button button-glass">
                <Phone size={17} />
                {PHONE}
              </a>
            </motion.div>
          </div>
          <a
            href="#boka"
            className="hero-scroll"
            aria-label="Gå till bokningen"
          >
            <ArrowDown size={19} />
          </a>
        </section>

        <section
          className="booking-section"
          id="boka"
          aria-labelledby="booking-title"
        >
          <div className="container">
            <div className="booking-heading">
              <h2 id="booking-title">Vart vill du åka?</h2>
              <p>Din nästa resa börjar här.</p>
            </div>
            <form
              className="booking-form"
              onSubmit={handleBooking}
              aria-labelledby="booking-title"
            >
              <div className="booking-fields">
                <div className="booking-field">
                  <MapPin className="field-icon" size={21} />
                  <div className="field-main">
                    <label htmlFor="pickup">Upphämtning</label>
                    <input
                      ref={pickupRef}
                      id="pickup"
                      name="pickup"
                      autoComplete="off"
                      list="kalmar-places"
                      placeholder="Var hämtar vi dig?"
                      value={pickup}
                      onChange={(event) => {
                        setPickup(event.target.value);
                        setFormError("");
                      }}
                      maxLength={120}
                      required
                    />
                  </div>
                  <button
                    type="button"
                    className="swap-route"
                    onClick={() => {
                      setPickup(destination);
                      setDestination(pickup);
                      setFormError("");
                    }}
                    aria-label="Byt plats på upphämtning och destination"
                    title="Byt riktning"
                  >
                    <ArrowDownUp size={17} />
                  </button>
                </div>
                <div className="booking-field">
                  <Navigation className="field-icon" size={20} />
                  <div className="field-main">
                    <label htmlFor="destination">Destination</label>
                    <input
                      id="destination"
                      name="destination"
                      autoComplete="off"
                      list="kalmar-places"
                      placeholder="Vart vill du åka?"
                      value={destination}
                      onChange={(event) => {
                        setDestination(event.target.value);
                        setFormError("");
                      }}
                      maxLength={120}
                      required
                    />
                  </div>
                </div>
                <div className="booking-field time-field">
                  <CalendarDays className="field-icon" size={20} />
                  <div className="field-main">
                    <label htmlFor="timing">När vill du åka?</label>
                    <div className="select-wrap">
                      <select
                        id="timing"
                        name="timing"
                        value={timing}
                        onChange={(event) => {
                          setTiming(event.target.value);
                          setFormError("");
                        }}
                      >
                        <option value="now">Så snart som möjligt</option>
                        <option value="scheduled">Välj datum & tid</option>
                      </select>
                      <ChevronDown size={15} />
                    </div>
                  </div>
                </div>
                <button
                  type="submit"
                  className="button button-dark booking-submit"
                >
                  Boka taxi <ArrowUpRight size={20} />
                </button>
              </div>
              <AnimatePresence>
                {timing === "scheduled" && (
                  <motion.div
                    className="schedule-row"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                  >
                    <label htmlFor="scheduled-at">
                      Önskat datum och tid för upphämtning (Kalmar-tid)
                    </label>
                    <input
                      id="scheduled-at"
                      name="scheduled-at"
                      type="datetime-local"
                      required
                      value={scheduledAt}
                      min={stockholmLocalDateTime(new Date())}
                      onChange={(event) => {
                        setScheduledAt(event.target.value);
                        setFormError("");
                      }}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
              {formError && (
                <p className="form-error" role="alert">
                  {formError}
                </p>
              )}
              <datalist id="kalmar-places">
                {places.map((place) => (
                  <option key={place} value={place} />
                ))}
              </datalist>
            </form>
            <p className="booking-note">
              <ShieldCheck size={14} /> Personlig bekräftelse på telefon. Ingen
              app, inget krångel.
            </p>
          </div>
        </section>

        <section
          className="services-section section-space"
          id="tjanster"
          aria-labelledby="services-title"
        >
          <div className="container">
            <Reveal className="section-heading split-heading">
              <div>
                <p className="eyebrow">
                  <span className="eyebrow-line" /> FÖR ALLA DINA RESOR
                </p>
                <h2 id="services-title">
                  Livet händer.
                  <br />
                  Vi kör dig dit.
                </h2>
              </div>
              <p className="section-intro">
                Vissa resor är stora. Andra är bara en del av dagen.
                <br className="desktop-break" /> Vi ger dem alla samma omtanke.
              </p>
            </Reveal>
            <div className="services-grid">
              {services.map((service, index) => (
                <Reveal key={service.number} delay={index * 0.1}>
                  <button
                    className="service-item group"
                    onClick={() => goToBooking(service)}
                    aria-label={service.label}
                  >
                    <div className="service-image">
                      <img
                        src={service.image}
                        alt={service.alt}
                        loading="lazy"
                        onError={(event) => {
                          const image = event.currentTarget;
                          if (image.src !== service.fallbackImage) {
                            image.src = service.fallbackImage;
                          }
                        }}
                      />
                      <span className="service-image-action">
                        <ArrowUpRight size={24} />
                      </span>
                    </div>
                    <div className="service-title">
                      <span className="service-number">{service.number}</span>
                      <h3>{service.title}</h3>
                      <ArrowUpRight className="service-arrow" size={23} />
                    </div>
                    <p>{service.description}</p>
                  </button>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section
          className="experience-section"
          id="om-oss"
          aria-labelledby="experience-title"
        >
          <div className="container experience-grid">
            <Reveal className="experience-image">
              <img
                src="/images/comfortable-ride.jpg"
                alt="Omsorgsfulla detaljer och inbjudande lädersäten i en taxibil"
                loading="lazy"
              />
              <span className="image-caption">
                LITE MER OMTANKE. HELA VÄGEN.
              </span>
            </Reveal>
            <Reveal className="experience-copy" delay={0.12}>
              <p className="eyebrow">
                <span className="eyebrow-line" /> NÄRA, PÅ RIKTIGT
              </p>
              <h2 id="experience-title">
                En skönare resa.
                <br />
                <span>Hela vägen.</span>
              </h2>
              <p className="experience-intro">
                Vi är inte bara en bil på väg. Vi är lokala förare som bryr oss
                om din resa, och om staden vi delar.
              </p>
              <div className="benefits">
                <div className="benefit">
                  <MapPin size={22} />
                  <div>
                    <h3>Vi kan vårt Kalmar.</h3>
                    <p>
                      Från kullerstenen i Gamla stan till vägarna över Öland. Du
                      är på hemmaplan med oss.
                    </p>
                  </div>
                </div>
                <div className="benefit">
                  <Clock3 size={22} />
                  <div>
                    <h3>Din tid är viktig.</h3>
                    <p>
                      Tidigt flyg eller sen kväll? Planera i förväg eller ring
                      när du behöver oss.
                    </p>
                  </div>
                </div>
                <div className="benefit">
                  <ShieldCheck size={22} />
                  <div>
                    <h3>Tryggt från dörr till dörr.</h3>
                    <p>
                      Personlig service, tydliga besked och en bekväm stund att
                      bara vara.
                    </p>
                  </div>
                </div>
              </div>
              <a className="text-link light-link" href={PHONE_LINK}>
                Lär känna oss på en resa <ArrowUpRight size={20} />
              </a>
            </Reveal>
          </div>
        </section>

        <section
          className="how-section section-space"
          id="sa-funkar-det"
          aria-labelledby="how-title"
        >
          <div className="container">
            <Reveal className="section-heading split-heading">
              <div>
                <p className="eyebrow">
                  <span className="eyebrow-line" /> ENKELT FRÅN START
                </p>
                <h2 id="how-title">
                  Tre små steg.
                  <br />
                  Sedan är du på väg.
                </h2>
              </div>
              <a href="#boka" className="text-link">
                Boka din första resa <ArrowUpRight size={21} />
              </a>
            </Reveal>
            <div className="steps-grid">
              {[
                [
                  "01",
                  "Säg vart du vill.",
                  "Välj upphämtning, destination och när du vill åka. Nu eller lite senare.",
                ],
                [
                  "02",
                  "Vi löser resten.",
                  "Ring oss för att bekräfta resan. Vi stämmer av tid, pris och det du behöver.",
                ],
                [
                  "03",
                  "Luta dig tillbaka.",
                  "Din förare tar hand om vägen. Du tar hand om det som väntar när du kommer fram.",
                ],
              ].map(([number, title, description], index) => (
                <Reveal key={number} className="step" delay={index * 0.1}>
                  <div className="step-top">
                    <span>{number}</span>
                    <ArrowRight size={22} />
                  </div>
                  <h3>{title}</h3>
                  <p>{description}</p>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section
          className="pricing-section section-space"
          id="priser"
          aria-labelledby="pricing-title"
        >
          <div className="container pricing-grid">
            <Reveal className="pricing-heading">
              <p className="eyebrow">
                <span className="eyebrow-line" /> TYDLIGT OCH RIMLIGT
              </p>
              <h2 id="pricing-title">
                Tydliga taxor.
                <br />
                Hela dygnet.
              </h2>
              <p>
                Priset beror på när du reser, hur långt du åker och hur lång tid
                resan tar. Här ser du våra taxor.
              </p>
              <a className="text-link" href={PHONE_LINK}>
                Fråga om din resa <ArrowUpRight size={20} />
              </a>
            </Reveal>
            <Reveal className="fares" delay={0.1}>
              <div className="fare-table-heading" aria-hidden="true">
                <span>Taxa och tid</span>
                <span>Jämförpris</span>
              </div>
              <div className="fare-list">
                {tariffs.map((tariff) => (
                  <article className="fare-row" key={tariff.id}>
                    <div className="fare-details">
                      <span className="fare-label">{tariff.label}</span>
                      <h3>{tariff.title}</h3>
                      <p className="fare-hours">{tariff.hours}</p>
                      <p className="fare-formula">
                        {tariff.base} kr grundavgift + {tariff.perKilometer}{" "}
                        kr/km + {tariff.perHour.toLocaleString("sv-SE")} kr/tim
                      </p>
                    </div>
                    <strong className="fare-price">
                      <span className="sr-only">Jämförpris </span>
                      {tariff.comparison} <span>kr</span>
                    </strong>
                  </article>
                ))}
              </div>
              <p className="fare-note">
                <strong>Jämförpriset</strong> gäller en exempelresa på 10 km som
                tar 15 minuter. Det är inte ett fast pris för din resa.
              </p>
              <p className="fare-note">
                För dagtid på helger och helgdagar, fråga oss om rätt taxa.
                Flygplatsavgift på {airportFee} kr tillkommer vid flygplatsresa.
                Väntetidsavgift och stations-/terminalavgift kan tillkomma.
                Begär alltid taxameterkvitto.
              </p>
            </Reveal>
          </div>
        </section>

        <section className="trust-section" aria-labelledby="trust-title">
          <div className="container trust-grid">
            <Reveal>
              <p className="eyebrow">
                <span className="eyebrow-line" /> FÖRTROENDE SOM FÖLJER MED
              </p>
              <h2 id="trust-title">
                Det bästa betyget?
                <br />
                Att du väljer oss igen.
              </h2>
              <p>
                Små möten. Många mil. Samma omtanke.
                <br />
                Tack för att vi får vara en del av din vardag.
              </p>
              <a
                className="text-link"
                href="https://www.google.com/search?q=Din+Taxi+Kalmar+omd%C3%B6men"
                target="_blank"
                rel="noopener noreferrer"
              >
                Läs kundomdömen <ArrowUpRight size={20} />
              </a>
            </Reveal>
            <Reveal className="review-summary" delay={0.15}>
              <div className="rating-number">
                4,2<span>/ 5</span>
              </div>
              <div
                className="rating-stars"
                role="img"
                aria-label="4,2 av 5 stjärnor"
              >
                {[0, 1, 2, 3, 4].map((star) => (
                  <Star
                    key={star}
                    size={23}
                    strokeWidth={1.5}
                    fill={star < 4 ? "currentColor" : "none"}
                  />
                ))}
              </div>
              <p>52 kundomdömen</p>
              <a
                className="rating-source"
                href="https://www.google.com/search?q=Din+Taxi+Kalmar+Kundernas.se"
                target="_blank"
                rel="noopener noreferrer"
              >
                Sammanställt på Kundernas.se <ArrowUpRight size={12} />
              </a>
              <span className="rating-disclaimer">
                Betyg och antal kan förändras.
              </span>
            </Reveal>
          </div>
        </section>

        <section
          className="faq-section section-space"
          id="fragor"
          aria-labelledby="faq-title"
        >
          <div className="container faq-grid">
            <Reveal className="faq-heading">
              <p className="eyebrow">
                <span className="eyebrow-line" /> BRA ATT VETA
              </p>
              <h2 id="faq-title">
                En fråga
                <br />
                på vägen?
              </h2>
              <p>
                Här är svaren på några vanliga frågor.
                <br />
                Annars är vi bara ett samtal bort.
              </p>
              <a className="text-link" href={PHONE_LINK}>
                <Phone size={17} />
                {PHONE}
              </a>
            </Reveal>
            <Reveal className="faq-list" delay={0.1}>
              {questions.map((faq, index) => (
                <div
                  className={`faq-item ${openFaq === index ? "is-open" : ""}`}
                  key={faq.question}
                >
                  <h3>
                    <button
                      id={`faq-button-${index}`}
                      aria-expanded={openFaq === index}
                      aria-controls={`faq-panel-${index}`}
                      onClick={() =>
                        setOpenFaq(openFaq === index ? null : index)
                      }
                    >
                      {faq.question}
                      <Plus size={20} />
                    </button>
                  </h3>
                  <AnimatePresence initial={false}>
                    {openFaq === index && (
                      <motion.div
                        id={`faq-panel-${index}`}
                        role="region"
                        aria-labelledby={`faq-button-${index}`}
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.28 }}
                      >
                        <p>{faq.answer}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </Reveal>
          </div>
        </section>

        <section className="final-cta" aria-labelledby="cta-title">
          <div className="container cta-inner">
            <Reveal>
              <p className="eyebrow">HELA KALMAR. HELA DYGNET.</p>
              <h2 id="cta-title">
                Vi tar dig dit.
                <br />
                Du tar det lugnt.
              </h2>
            </Reveal>
            <Reveal className="cta-actions" delay={0.12}>
              <a className="button button-dark" href="#boka">
                Boka din nästa resa <ArrowUpRight size={23} />
              </a>
              <a className="cta-call" href={PHONE_LINK}>
                Eller ring oss på <strong>{PHONE}</strong>
              </a>
            </Reveal>
          </div>
          <svg
            className="cta-art"
            viewBox="0 0 400 400"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M250-80 20 320h85L335-80M365-80 135 320h85L450-80"
              stroke="currentColor"
              strokeWidth="2"
            />
          </svg>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container">
          <div className="footer-main">
            <div className="footer-brand">
              <Brand light />
              <p>
                En del av din vardag.
                <br />
                En del av Kalmar.
              </p>
            </div>
            <div className="footer-links">
              <h3>På väg med oss</h3>
              <a href="#tjanster">Våra tjänster</a>
              <a href="#om-oss">Om Din Taxi</a>
              <a href="#priser">Priser</a>
              <a href="#fragor">Vanliga frågor</a>
            </div>
            <div className="footer-links">
              <h3>Vi finns här</h3>
              <a className="footer-phone" href={PHONE_LINK}>
                {PHONE}
                <ArrowUpRight size={17} />
              </a>
              <span>Alla dagar, dygnet runt.</span>
              <span>Kalmar, Sverige</span>
            </div>
            <div className="footer-links footer-places">
              <h3>På hemmaplan i</h3>
              <span>Kalmar & Öland</span>
              <span>Nybro & Lindsdal</span>
              <span>Och dit du behöver.</span>
            </div>
          </div>
          <div className="footer-bottom">
            <p>
              © {new Date().getFullYear()} Din Taxi Kalmar. Alla rättigheter
              förbehållna.
            </p>
            <div>
              <button onClick={() => setLegal("privacy")}>
                Integritetspolicy
              </button>
              <button onClick={() => setLegal("accessibility")}>
                Tillgänglighet
              </button>
              <a href="#hem" aria-label="Till sidans topp">
                Till toppen <ArrowUpRight size={15} />
              </a>
            </div>
          </div>
        </div>
      </footer>

      {bookingOpen && (
        <Dialog onClose={() => setBookingOpen(false)} titleId="journey-title">
          <div className="dialog-eyebrow">
            <span className="live-dot" /> DIN TAXI KALMAR
          </div>
          <h2 id="journey-title">Snart på väg.</h2>
          <p className="dialog-description">
            Här är din resa. Ring oss så bekräftar vi pris, tid och vilken bil
            som passar dig.
          </p>
          <div className="journey-route">
            <div>
              <span className="route-dot" />
              <span>
                <small>UPPHÄMTNING</small>
                <strong>{pickup.trim()}</strong>
              </span>
            </div>
            <div>
              <MapPin size={18} />
              <span>
                <small>DESTINATION</small>
                <strong>{destination.trim()}</strong>
              </span>
            </div>
          </div>
          <div className="journey-time">
            <CalendarDays size={18} />
            <span>{journeyTime}</span>
          </div>
          <div className="passenger-row">
            <span>
              <Users size={19} />
              Antal resenärer
            </span>
            <div className="stepper">
              <button
                className="icon-button"
                aria-label="En färre resenär"
                disabled={passengers <= 1}
                onClick={() => {
                  setPassengers(passengers - 1);
                  setCopyState("idle");
                }}
              >
                <Minus size={16} />
              </button>
              <output aria-live="polite">{passengers}</output>
              <button
                className="icon-button"
                aria-label="En till resenär"
                disabled={passengers >= 8}
                onClick={() => {
                  setPassengers(passengers + 1);
                  setCopyState("idle");
                }}
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
          {passengers > 4 && (
            <p className="passenger-note">
              Fråga om en större bil när du ringer. Tillgänglighet bekräftas av
              oss.
            </p>
          )}
          <section
            className="journey-fare"
            aria-live="polite"
            aria-label="Jämförpris"
          >
            <div className="journey-fare-heading">
              <div>
                <span className="journey-fare-label">
                  {passengers > 4
                    ? "Jämförpris om du behöver storbil"
                    : "Jämförpris för din tid"}
                </span>
                <strong className="journey-fare-period">
                  {journeyTariff
                    ? `${journeyTariff.label} · ${journeyTariff.title} ${journeyTariff.hours}`
                    : "Taxa bekräftas på telefon"}
                </strong>
              </div>
              {journeyTariff && (
                <strong className="journey-fare-price">
                  {journeyTariff.comparison} <span>kr</span>
                </strong>
              )}
            </div>
            <p>
              {journeyTariff
                ? "Exempel för 10 km som tar 15 minuter, inte priset för din resa."
                : "För dagtid på helger och helgdagar bekräftar vi rätt taxa när du ringer."}{" "}
              Flygplatsavgift på {airportFee} kr tillkommer vid flygplatsresa.
            </p>
          </section>
          <a className="button button-lime dialog-call" href={PHONE_LINK}>
            <Phone size={19} />
            Ring och boka {PHONE}
            <ArrowUpRight size={20} />
          </a>
          <p className="confirmation-note">
            <ShieldCheck size={15} />
            Resan är bokad först när vi bekräftat den på telefon.
          </p>
          <div className="journey-tools">
            <button
              onClick={() => {
                setBookingOpen(false);
                goToBooking();
              }}
            >
              Ändra resan
            </button>
            <button onClick={copyJourney}>
              {copyState === "copied" ? (
                <Check size={15} />
              ) : (
                <Copy size={15} />
              )}
              {copyState === "copied"
                ? "Resuppgifter kopierade"
                : "Kopiera resuppgifter"}
            </button>
          </div>
          <span className="sr-only" role="status">
            {copyState === "copied" ? "Resuppgifterna har kopierats." : ""}
          </span>
          {copyState === "error" && (
            <p className="form-error" role="alert">
              Kunde inte kopiera. Du kan läsa upp uppgifterna när du ringer.
            </p>
          )}
        </Dialog>
      )}

      {legal && (
        <Dialog onClose={() => setLegal(null)} titleId="legal-title">
          <p className="eyebrow">DIN TAXI KALMAR</p>
          <h2 id="legal-title">
            {legal === "privacy" ? "Din integritet." : "En sida för alla."}
          </h2>
          {legal === "privacy" ? (
            <div className="legal-copy">
              <p>
                Uppgifterna du skriver i reseplaneraren behandlas bara i din
                webbläsare. De skickas inte automatiskt till Din Taxi Kalmar och
                sparas inte när du laddar om sidan.
              </p>
              <h3>När du bokar</h3>
              <p>
                Din bokning sker på telefon. Vi använder uppgifterna du lämnar
                för att planera och genomföra din resa. Ring {PHONE} om du har
                frågor om hur dina uppgifter hanteras.
              </p>
              <h3>Kakor och externa tjänster</h3>
              <p>
                Den här sidan använder inte analyskakor eller
                marknadsföringskakor. Typsnitt hämtas från Google Fonts. Om en
                lokal tjänstebild inte kan laddas används en bild från Pexels.
                Externa länkar öppnar tjänster med egna integritetsvillkor.
              </p>
            </div>
          ) : (
            <div className="legal-copy">
              <p>
                Vi vill att det ska vara enkelt för alla att planera en resa.
                Sidan har tydliga formuläretiketter, tangentbordsnavigation,
                synliga fokusmarkeringar och stöd för minskad rörelse.
              </p>
              <h3>Behöver du hjälp?</h3>
              <p>
                Du kan alltid boka direkt på telefon {PHONE}. Berätta om dina
                behov så hjälper vi dig att planera resan och bekräftar vilken
                bil som finns tillgänglig.
              </p>
              <a className="button button-dark" href={PHONE_LINK}>
                <Phone size={17} />
                Ring oss
              </a>
            </div>
          )}
        </Dialog>
      )}
    </MotionConfig>
  );
}

export default App;
