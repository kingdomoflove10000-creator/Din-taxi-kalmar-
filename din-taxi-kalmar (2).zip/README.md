# Din Taxi Kalmar

A responsive Swedish-language taxi landing page built with React, TypeScript,
Vite, Tailwind CSS v4, Motion, and Lucide icons.

## Development

- `npm install`
- `npm run dev`
- `npx tsc --noEmit`
- `npm run build`
- `npm run preview`

The production output is in `dist/`. Deploy the entire directory, including the
local images and favicon, to a static hosting provider.

## Booking

The trip planner validates pickup, destination, and an optional future pickup
time. The accessible journey dialog includes a passenger selector and lets
visitors copy their travel details or call the operator at +46 480 47 47 47.
Scheduled pickup times use local Kalmar (Europe/Stockholm) time. The booking
dialog shows the matching comparison tariff when it can be determined from the
provided notice. Weekend and public-holiday daytime tariffs are not guessed;
visitors are asked to confirm them by phone. For more than four passengers, the
dialog shows the large-vehicle comparison as conditional on needing a large car.

Reservations are confirmed by the operator on the phone. The site does not
claim to dispatch a vehicle, charge a card, or submit a reservation to a backend.
Trip details stay in browser memory and are not persisted or transmitted.

## Verification

- Install the browser once: `npx playwright install --with-deps chromium`
- Run all browser checks: `npx playwright test`
- Screenshots are generated in `artifacts/`.

The tests cover form validation, scheduling, route swapping, service shortcuts,
tariff rates and time boundaries, passenger counts, clipboard behavior, phone
links, native dialog focus containment, FAQ interactions, footer dialogs, and
responsive overflow.
Automated WCAG A/AA checks use axe-core on the landing page and booking dialog.
Automated checks do not replace manual assistive-technology testing.

## Content And Assets

The operator's phone number is corroborated by kalmar-taxi.se and the taxi
directory at kalmarolandairport.se. The time-based tariff details and 25 SEK
airport fee come from the supplied Din Taxi Kalmar price notice. Comparison
prices are for a journey of 10 km taking 15 minutes, not fixed journey quotes.
The notice does not specify weekend or public-holiday daytime applicability;
that should be confirmed with the operator. The 4.2/5 aggregate from 52 reviews
was listed by Kundernas.se;
the page identifies the source and notes that ratings can change. No customer
quotations or identities have been invented. Confirm current fares, fleet
details, and review totals with the operator before a business launch.

The waterfront hero and tan interior are AI-generated illustrative brand
photography, not a representation of the operator's actual fleet. Other photos
are from Pexels: Kalmar Castle by wim de mont (33396540), flight by Chris F
(11618710), and vehicle interior by Luke Miller (14667496). All imagery is
served locally, with Pexels URLs as a fallback for the three service photos if
local files are missing. Manrope is loaded through Google Fonts; both external
sources are disclosed in the privacy dialog.
