import { test, expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { mkdir } from "node:fs/promises";
import {
  standardTariffForTime,
  stockholmLocalDateTime,
  tariffs,
} from "../src/utils/tariffs";

async function loadPage(page: Page) {
  await page.goto("/", { waitUntil: "networkidle" });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(800);
}

async function revealSections(page: Page) {
  const height = await page.evaluate(
    () => document.documentElement.scrollHeight,
  );
  for (let top = 0; top < height; top += 650) {
    await page.evaluate(
      (y) => window.scrollTo({ top: y, behavior: "instant" }),
      top,
    );
    await page.waitForTimeout(130);
  }
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: "instant" }));
  await page.waitForTimeout(800);
}

test("desktop page, images, console, and accessibility", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await loadPage(page);
  await expect(page).toHaveTitle("Din Taxi Kalmar | Din taxi. Ditt Kalmar.");
  await expect(page.getByRole("heading", { level: 1 })).toContainText(
    "Din taxi.",
  );
  await revealSections(page);
  const brokenImages = await page
    .locator("img")
    .evaluateAll((images) =>
      images
        .filter((image) => !image.complete || image.naturalWidth === 0)
        .map((image) => image.src),
    );
  expect(brokenImages).toEqual([]);
  expect(errors).toEqual([]);
  await mkdir("artifacts", { recursive: true });
  await page.screenshot({ path: "artifacts/desktop.png" });
  await page.screenshot({ path: "artifacts/desktop-full.png", fullPage: true });
  const accessibility = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(
    accessibility.violations,
    JSON.stringify(
      accessibility.violations.map((violation) => ({
        id: violation.id,
        impact: violation.impact,
        nodes: violation.nodes.map((node) => ({
          target: node.target,
          summary: node.failureSummary,
        })),
      })),
      null,
      2,
    ),
  ).toEqual([]);
});

test("trip planning, scheduling, passengers, copying, and phone booking", async ({
  page,
}) => {
  await loadPage(page);
  await page
    .getByLabel("Upphämtning", { exact: true })
    .fill("Kalmar Centralstation");
  await page
    .getByLabel("Destination", { exact: true })
    .fill("Kalmar Öland Airport");
  await page
    .getByLabel("När vill du åka?", { exact: true })
    .selectOption("scheduled");
  const future = new Date(Date.now() + 2 * 86400000);
  const dateTime = new Date(
    future.getTime() - future.getTimezoneOffset() * 60000,
  )
    .toISOString()
    .slice(0, 16);
  await page.getByLabel("Önskat datum och tid för upphämtning").fill(dateTime);
  await page.locator(".booking-submit").click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await expect(dialog).toContainText("Kalmar Centralstation");
  await expect(dialog).toContainText("Kalmar Öland Airport");
  await expect(
    dialog.getByRole("link", { name: /Ring och boka/ }),
  ).toHaveAttribute("href", "tel:+46480474747");
  await expect(
    dialog.getByRole("button", { name: "En färre resenär" }),
  ).toBeDisabled();
  for (let i = 0; i < 4; i++)
    await dialog.getByRole("button", { name: "En till resenär" }).click();
  await expect(dialog.locator("output")).toHaveText("5");
  await expect(dialog).toContainText("Fråga om en större bil");
  await dialog.getByRole("button", { name: "Kopiera resuppgifter" }).click();
  await expect(
    dialog.getByRole("button", { name: "Resuppgifter kopierade" }),
  ).toBeVisible();
  expect(await page.evaluate(() => navigator.clipboard.readText())).toContain(
    "Resenärer: 5",
  );
  const accessibility = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(
    accessibility.violations.map((violation) => ({
      id: violation.id,
      nodes: violation.nodes.map((node) => node.target),
    })),
  ).toEqual([]);
  await page.screenshot({ path: "artifacts/booking-dialog.png" });
  await dialog.getByRole("button", { name: "Stäng dialog" }).focus();
  await page.keyboard.press("Shift+Tab");
  expect(
    await page.evaluate(() =>
      document.querySelector("dialog")?.contains(document.activeElement),
    ),
  ).toBe(true);
  await page.keyboard.press("Escape");
  await expect(dialog).not.toBeVisible();
  await expect(page.locator("body")).not.toHaveCSS("overflow", "hidden");
});

test("validation, route swapping, and service shortcuts", async ({ page }) => {
  await loadPage(page);
  await page.getByLabel("Upphämtning", { exact: true }).fill("Kalmar Slott");
  await page.getByLabel("Destination", { exact: true }).fill("Kalmar Slott");
  await page.locator(".booking-submit").click();
  await expect(page.getByRole("alert")).toContainText("olika platser");
  await page.getByLabel("Destination", { exact: true }).fill("Stortorget");
  await page
    .getByRole("button", { name: "Byt plats på upphämtning och destination" })
    .click();
  await expect(page.getByLabel("Upphämtning", { exact: true })).toHaveValue(
    "Stortorget",
  );
  await expect(page.getByLabel("Destination", { exact: true })).toHaveValue(
    "Kalmar Slott",
  );
  await page.getByRole("button", { name: "Boka flygplatstaxi" }).click();
  await expect(page.getByLabel("Destination", { exact: true })).toHaveValue(
    "Kalmar Öland Airport",
  );
});

test("service imagery falls back if a local asset is unavailable", async ({
  page,
}) => {
  await page.route("**/images/kalmar-castle.jpg", (route) =>
    route.fulfill({ status: 404, body: "not found" }),
  );
  await page.route("https://images.pexels.com/photos/33396540/**", (route) =>
    route.fulfill({
      path: "public/images/kalmar-castle.jpg",
      contentType: "image/jpeg",
    }),
  );
  await loadPage(page);
  const image = page.getByRole("img", {
    name: "Kalmar Slott speglar sig i det stilla vattnet",
  });
  await image.scrollIntoViewIfNeeded();
  await expect(image).toHaveAttribute("src", /images\.pexels\.com/);
  await expect
    .poll(() =>
      image.evaluate((node) => (node as HTMLImageElement).naturalWidth),
    )
    .toBeGreaterThan(0);
});

test("the posted tariffs and comparison prices match the price notice", async ({
  page,
}) => {
  await loadPage(page);
  const pricing = page.locator("#priser");
  const rows = pricing.locator(".fare-row");
  await expect(rows).toHaveCount(3);
  await expect(rows.nth(0)).toContainText("Taxa 1");
  await expect(rows.nth(0)).toContainText("Vardagar");
  await expect(rows.nth(0)).toContainText("08:00-15:00");
  await expect(rows.nth(0)).toContainText(
    "65 kr grundavgift + 26 kr/km + 500 kr/tim",
  );
  await expect(rows.nth(0)).toContainText("450 kr");
  await expect(rows.nth(1)).toContainText("Övriga tider");
  await expect(rows.nth(1)).toContainText("15:00-08:00");
  await expect(rows.nth(1)).toContainText(
    "65 kr grundavgift + 27 kr/km + 600 kr/tim",
  );
  await expect(rows.nth(1)).toContainText("485 kr");
  await expect(rows.nth(2)).toContainText("Storbil");
  await expect(rows.nth(2)).toContainText("00:00-24:00");
  await expect(rows.nth(2)).toContainText(
    "80 kr grundavgift + 30 kr/km + 1 000 kr/tim",
  );
  await expect(rows.nth(2)).toContainText("630 kr");
  await expect(pricing).toContainText("10 km som tar 15 minuter");
  await expect(pricing).toContainText("inte ett fast pris");
  await expect(pricing).toContainText("För dagtid på helger och helgdagar");
  await expect(pricing).toContainText("Flygplatsavgift på 25 kr");
  await expect(pricing).toContainText(
    "Väntetidsavgift och stations-/terminalavgift",
  );
  await expect(pricing).not.toContainText("från 150");
  await expect(pricing).not.toContainText("från 270");
  await pricing.scrollIntoViewIfNeeded();
  await page.screenshot({ path: "artifacts/pricing-desktop.png" });
  for (const tariff of tariffs) {
    expect(tariff.base + 10 * tariff.perKilometer + tariff.perHour / 4).toBe(
      tariff.comparison,
    );
  }
});

test("standard fares respect time boundaries without guessing weekends or holidays", () => {
  expect(standardTariffForTime("2026-06-02T07:59")?.comparison).toBe(485);
  expect(standardTariffForTime("2026-06-02T08:00")?.comparison).toBe(450);
  expect(standardTariffForTime("2026-06-02T14:59")?.comparison).toBe(450);
  expect(standardTariffForTime("2026-06-02T15:00")?.comparison).toBe(485);
  expect(standardTariffForTime("2026-06-06T10:00")).toBeNull();
  expect(standardTariffForTime("2026-06-07T14:59")).toBeNull();
  expect(standardTariffForTime("2026-04-03T10:00")).toBeNull();
  expect(standardTariffForTime("2026-04-06T10:00")).toBeNull();
  expect(standardTariffForTime("2026-05-14T10:00")).toBeNull();
  expect(standardTariffForTime("2026-06-06T15:00")?.comparison).toBe(485);
  expect(standardTariffForTime("2026-02-30T10:00")).toBeNull();
  expect(stockholmLocalDateTime(new Date("2026-06-02T06:00:00Z"))).toBe(
    "2026-06-02T08:00",
  );
  expect(stockholmLocalDateTime(new Date("2026-12-02T06:00:00Z"))).toBe(
    "2026-12-02T07:00",
  );
});

test("booking shows the relevant comparison price and large-vehicle rate", async ({
  page,
}) => {
  await page.clock.setFixedTime(new Date("2026-06-01T04:00:00Z"));
  await loadPage(page);
  await page
    .getByLabel("Upphämtning", { exact: true })
    .fill("Kalmar Centralstation");
  await page
    .getByLabel("Destination", { exact: true })
    .fill("Kalmar Öland Airport");
  await page
    .getByLabel("När vill du åka?", { exact: true })
    .selectOption("scheduled");
  const scheduled = page.getByLabel("Önskat datum och tid för upphämtning");
  const dialog = page.getByRole("dialog");
  const preview = dialog.locator(".journey-fare");

  for (const [time, amount] of [
    ["2026-06-02T07:59", "485 kr"],
    ["2026-06-02T08:00", "450 kr"],
    ["2026-06-02T14:59", "450 kr"],
    ["2026-06-02T15:00", "485 kr"],
  ]) {
    await scheduled.fill(time);
    await page.locator(".booking-submit").click();
    await expect(preview).toContainText(amount);
    await expect(preview).toContainText("inte priset för din resa");
    await expect(preview).toContainText("Flygplatsavgift på 25 kr");
    await dialog.getByRole("button", { name: "Stäng dialog" }).click();
  }

  await scheduled.fill("2026-06-06T10:00");
  await page.locator(".booking-submit").click();
  await expect(preview).toContainText("Taxa bekräftas på telefon");
  await expect(preview).not.toContainText("450 kr");
  for (let i = 0; i < 4; i++) {
    await dialog.getByRole("button", { name: "En till resenär" }).click();
  }
  await expect(preview).toContainText("Jämförpris om du behöver storbil");
  await expect(preview).toContainText("630 kr");
  await expect(preview).toContainText("00:00-24:00");
});

test("immediate pickup uses the current time in Kalmar", async ({ page }) => {
  await page.clock.setFixedTime(new Date("2026-06-01T05:59:00Z"));
  await loadPage(page);
  await page.getByLabel("Upphämtning", { exact: true }).fill("Kalmar Slott");
  await page
    .getByLabel("Destination", { exact: true })
    .fill("Kalmar Centralstation");
  await page.locator(".booking-submit").click();
  await expect(page.locator(".journey-fare")).toContainText("485 kr");
  await page.getByRole("button", { name: "Stäng dialog" }).click();
  await page.clock.setFixedTime(new Date("2026-06-01T06:00:00Z"));
  await page.locator(".booking-submit").click();
  await expect(page.locator(".journey-fare")).toContainText("450 kr");
});

test("tariffs and the booking action remain usable on a small phone", async ({
  page,
}) => {
  await page.setViewportSize({ width: 320, height: 568 });
  await loadPage(page);
  await page.locator("#priser").scrollIntoViewIfNeeded();
  for (const price of ["450 kr", "485 kr", "630 kr"]) {
    await expect(
      page.locator("#priser .fare-price").getByText(price),
    ).toBeVisible();
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(
    320,
  );
  await page.getByLabel("Upphämtning", { exact: true }).fill("Kalmar Slott");
  await page
    .getByLabel("Destination", { exact: true })
    .fill("Kalmar Centralstation");
  await page.locator(".booking-submit").click();
  const dialog = page.getByRole("dialog");
  const call = dialog.getByRole("link", { name: /Ring och boka/ });
  await call.scrollIntoViewIfNeeded();
  await expect(call).toHaveAttribute("href", "tel:+46480474747");
  const bounds = await call.boundingBox();
  expect(bounds).not.toBeNull();
  expect(bounds!.x).toBeGreaterThanOrEqual(0);
  expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(320);
  expect(bounds!.y + bounds!.height).toBeLessThanOrEqual(568);
  const accessibility = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(accessibility.violations.map((violation) => violation.id)).toEqual([]);
});

test.describe("booking from a different time zone", () => {
  test.use({ timezoneId: "America/New_York" });
  test("scheduled times use local Kalmar time", async ({ page }) => {
    await page.clock.setFixedTime(new Date("2026-06-01T07:00:00Z"));
    await loadPage(page);
    await page.getByLabel("Upphämtning", { exact: true }).fill("Kalmar Slott");
    await page
      .getByLabel("Destination", { exact: true })
      .fill("Kalmar Centralstation");
    await page
      .getByLabel("När vill du åka?", { exact: true })
      .selectOption("scheduled");
    const scheduled = page.getByLabel("Önskat datum och tid för upphämtning");
    await expect(scheduled).toHaveAttribute("min", "2026-06-01T09:00");
    await scheduled.fill("2026-06-01T09:30");
    await page.locator(".booking-submit").click();
    await expect(page.getByRole("dialog")).toContainText("09:30");
    await expect(page.locator(".journey-fare")).toContainText("450 kr");
  });
});

test("FAQ and footer dialogs work with keyboard dismissal", async ({
  page,
}) => {
  await loadPage(page);
  const faq = page.getByRole("button", {
    name: "Kan jag boka en resa i förväg?",
  });
  await faq.click();
  await expect(faq).toHaveAttribute("aria-expanded", "true");
  await expect(page.locator("#faq-panel-1")).toBeVisible();
  await faq.click();
  await expect(faq).toHaveAttribute("aria-expanded", "false");
  await page
    .getByRole("button", { name: "Integritetspolicy", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toContainText("Din integritet.");
  const privacyAccessibility = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(
    privacyAccessibility.violations.map((violation) => ({
      id: violation.id,
      nodes: violation.nodes.map((node) => ({
        target: node.target,
        summary: node.failureSummary,
      })),
    })),
  ).toEqual([]);
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page
    .getByRole("button", { name: "Tillgänglighet", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toContainText("En sida för alla.");
  await page.getByRole("button", { name: "Stäng dialog" }).click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
});

test("responsive layouts and mobile menu", async ({ page }) => {
  await loadPage(page);
  for (const width of [320, 360, 390, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 844 });
    await page.waitForTimeout(120);
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth),
      `horizontal overflow at ${width}px`,
    ).toBeLessThanOrEqual(width);
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole("button", { name: "Öppna meny" }).click();
  await expect(
    page.getByRole("navigation", { name: "Mobilnavigation" }),
  ).toBeVisible();
  await page
    .getByRole("navigation", { name: "Mobilnavigation" })
    .getByRole("link", { name: "Våra tjänster" })
    .click();
  await expect(
    page.getByRole("navigation", { name: "Mobilnavigation" }),
  ).not.toBeVisible();
  await revealSections(page);
  await page.screenshot({ path: "artifacts/mobile.png" });
  await page.screenshot({ path: "artifacts/mobile-full.png", fullPage: true });
  const mobileAccessibility = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(
    mobileAccessibility.violations.map((violation) => ({
      id: violation.id,
      targets: violation.nodes.map((node) => node.target),
    })),
  ).toEqual([]);
});
